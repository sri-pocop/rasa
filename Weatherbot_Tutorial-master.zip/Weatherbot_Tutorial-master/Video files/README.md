# Weatherbot Tutorial (Video files)

This directory contains the 'getting started' files which you can take and use if you want to create a bot as you watch the tutorial.

